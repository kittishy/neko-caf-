# Comandos de Utilidades
Coloque aqui os comandos relacionados a utilidades e ferramentas úteis para o servidor.