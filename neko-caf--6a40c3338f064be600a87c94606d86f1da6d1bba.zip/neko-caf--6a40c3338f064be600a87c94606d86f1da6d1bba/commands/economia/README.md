# Comandos de Economia
Coloque aqui os comandos relacionados a economia, moedas virtuais, lojas, etc.