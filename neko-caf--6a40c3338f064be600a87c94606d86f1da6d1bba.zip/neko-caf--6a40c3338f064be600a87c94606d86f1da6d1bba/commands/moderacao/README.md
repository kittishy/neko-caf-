# Comandos de Moderação
Coloque aqui os comandos relacionados à moderação do servidor.